import List from './todo';
import ToggleButton from './toggleButton';
import SearchFilter from './Filter';
import Timer from './Timer_component';

function App() {  return (
  <>
   <List/>
   <ToggleButton/>
   <Timer/>
    <SearchFilter/>
  </>
  );
}

export default App;
